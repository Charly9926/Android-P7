package mx.edu.tesoem.isc.p77s2120222cmjycmpb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class NativoActivity extends AppCompatActivity {

    TextView lblnombre, lbledad;
    Button btnregresa;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nativo);

        lblnombre = findViewById(R.id.lblnombre);
        lbledad = findViewById(R.id.lbledad);
        btnregresa = findViewById(R.id.btnregresa);

        Bundle parametros = getIntent().getExtras();
        String nombre = parametros.getString("nombre");
        int edad = parametros.getInt("edad");
        lblnombre.setText(nombre);
        lbledad.setText(edad);

        btnregresa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
}