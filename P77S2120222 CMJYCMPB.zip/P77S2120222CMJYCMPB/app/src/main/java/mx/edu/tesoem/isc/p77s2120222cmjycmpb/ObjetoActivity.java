package mx.edu.tesoem.isc.p77s2120222cmjycmpb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ObjetoActivity extends AppCompatActivity {

    TextView lblnombre, lbledad;
    Button btnregresa2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_objeto);

        lblnombre = findViewById(R.id.lblnombre);
        lbledad = findViewById(R.id.lbledad);
        btnregresa2 = findViewById(R.id.btnregresa2);

        Datos datos = getIntent().getParcelableExtra("datos");
        lblnombre.setText(datos.getNombre());
        lbledad.setText(String.valueOf((datos.getEdad())));

        btnregresa2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
}